package t2;

sub id { "t2pm" }

1;
