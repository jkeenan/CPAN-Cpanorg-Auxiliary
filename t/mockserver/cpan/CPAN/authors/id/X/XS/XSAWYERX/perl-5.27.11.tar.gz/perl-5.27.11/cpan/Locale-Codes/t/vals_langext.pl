#!/usr/bin/perl
# Copyright (c) 2016-2018 Sullivan Beck. All rights reserved.
# This program is free software; you can redistribute it and/or modify it
# under the same terms as Perl itself.

use warnings;
use strict;

$::tests = '';

$::tests = "

2code
Mesopotamian Arabic
   acm

2name
acm
   Mesopotamian Arabic

code2code
ACM
alpha
alpha
   acm

all_codes
2
   ~
   aao
   abh

all_names
2
   ~
   Adamorobe Sign Language
   Afghan Sign Language

";

1;
# Local Variables:
# mode: cperl
# indent-tabs-mode: nil
# cperl-indent-level: 3
# cperl-continued-statement-offset: 2
# cperl-continued-brace-offset: 0
# cperl-brace-offset: 0
# cperl-brace-imaginary-offset: 0
# cperl-label-offset: 0
# End:

